import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-step-from',
  templateUrl: './step-from.component.pug',
  styleUrls: ['./step-from.component.scss']
})
export class StepFromComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
