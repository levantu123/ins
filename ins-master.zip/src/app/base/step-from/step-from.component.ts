import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material';

@Component({
  selector: 'app-step-from',
  templateUrl: './step-from.component.pug',
  styleUrls: ['./step-from.component.scss']
})
export class StepFromComponent implements OnInit {

  constructor(public snackBar: MatSnackBar) { }

  ngOnInit() {
  }
  openMess(){
    this.snackBar.open('Submit successed', '', {
      duration: 2000,
      panelClass: ['white-snackbar']
    });
  }
}
