import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ListView } from '../list-view/listViewData';

@Component({
  selector: 'app-main-screen',
  templateUrl: './main-screen.component.pug',
  styleUrls: ['./main-screen.component.scss']
})
export class MainScreenComponent implements OnInit {

  constructor(private http: HttpClient) { }

  ngOnInit() {
    this.http.get("assets/list.config.json").subscribe((res:any)=>{
      this.listItem = res;
    });
    this.breakpoint = (window.innerWidth <= 800) ? 3 : 6;
  }
  data: ListView;
  listItem:any={
    "_embedded" : {
      "activities" : [ ]}
  };
  breakpoint:number;
  onResize(event) {
    this.breakpoint = (event.target.innerWidth <= 800) ? 3 : 6;
  }
}
