import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-narbar-menu',
  templateUrl: './narbar-menu.component.pug',
  styleUrls: ['./narbar-menu.component.scss']
})
export class NarbarMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
