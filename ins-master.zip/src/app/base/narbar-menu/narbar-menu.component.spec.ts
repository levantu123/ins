import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NarbarMenuComponent } from './narbar-menu.component';

describe('NarbarMenuComponent', () => {
  let component: NarbarMenuComponent;
  let fixture: ComponentFixture<NarbarMenuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NarbarMenuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NarbarMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
