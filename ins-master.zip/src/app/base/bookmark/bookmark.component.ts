import { Component, OnInit, Input } from '@angular/core';
import { Shortcut } from '../list-view/listViewData';

@Component({
  selector: 'app-bookmark',
  templateUrl: './bookmark.component.pug',
  styleUrls: ['./bookmark.component.scss']
})
export class BookmarkComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  @Input() data:Array<Shortcut>;
}
