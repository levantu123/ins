export interface ListView {
    name: string;
    url: string;
    title: string;
}

export interface Shortcut{
    name:string;
    url:string;
    title:string
}