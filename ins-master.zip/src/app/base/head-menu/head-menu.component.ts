import { Component, OnInit } from '@angular/core';
import { Shortcut } from '../list-view/listViewData';

@Component({
  selector: 'app-head-menu',
  templateUrl: './head-menu.component.pug',
  styleUrls: ['./head-menu.component.scss']
})
export class HeadMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
