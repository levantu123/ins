import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ListViewComponent } from './list-view/list-view.component';
import { HttpClientModule } from '@angular/common/http';
import { BookmarkComponent } from './bookmark/bookmark.component';
import { HeadMenuComponent } from './head-menu/head-menu.component';
import { MenuTreeComponent } from './menu-tree/menu-tree.component';
import { ListComponent } from './list/list.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { MaterialModule } from './material';
import { MainScreenComponent } from './main-screen/main-screen.component';
import { NarbarMenuComponent } from './narbar-menu/narbar-menu.component';
import { StepFromComponent } from './step-from/step-from.component';
import { MainLayoutComponent } from '../main-layout/main-layout.component';


@NgModule({
  declarations: [ListViewComponent, BookmarkComponent, HeadMenuComponent, MenuTreeComponent, ListComponent, MainScreenComponent, NarbarMenuComponent, StepFromComponent, MainLayoutComponent],
  imports: [
    CommonModule,
    HttpClientModule,
    BrowserAnimationsModule,
    MaterialModule
  ],
  exports: [MainScreenComponent],
  entryComponents:[NarbarMenuComponent]
})
export class BaseModule { }
