export interface ListView {
    name: string;
    url: string;
    title: string;
}